function createCursor() {
  cursor = new Sprite(-100, 112, 32);
  cursor.spriteSheet = cursorSprite;
  cursor.layer = 6;
  cursor.collider = "none";
  cursor.addAnis({
    shooting: {
      row: 0,
      col: 0,
      frames: 4,
      frameSize: [112, 32],
      frameDelay: 8,
    },
  });
  cursor.ani.noLoop();
  
  
  ball = new Sprite(player.x, player.y, 12, 12);
  ball.image = ballSprite;
  ball.layer = 1;
  ball.collider = "none";
  ball.mass = 0;
  ball.visible = false;

  pointer = new Sprite(player.x, player.y, 16, 16);
  pointer.spriteSheet = pointerSprite;
  pointer.layer = 6;
  pointer.collider = "none";
  pointer.addAnis({
    pointer: {
      row: 0,
      col: 0,
      frames: 1,
      frameSize: [16, 16],
      frameDelay: 8,
    },
  });
  


  dasher = new Sprite(player.x, player.y, 16, 16)
  dasher.layer = 2;
  dasher.collider = "none";
  dasher.visible = false;

  dashstart = new Sprite(player.x, player.y, 16, 16)
  dashstart.layer = 2;
  dashstart.collider = "none";
  dashstart.visible = false;
}

function shootCursor() {
  cursor.rotateTowards(mouse, 1, 0);
  cursor.x = player.x;
  cursor.y = player.y + 6;
  pointer.x = mouse.x;
  pointer.y = mouse.y;
  cursor.ani.frame = 0;

////////////////////////shoot////////////////////////////////
  if(mouse.pressed("left") && canshoot == 0) {
    s_slimeshoot.play();
    s_slimeshoot.setVolume(0.3);
    player.velocity.x = 0;
    ball.x = player.x;
    ball.y = player.y;
    ball.direction = ball.angleTo(pointer);
    ball.speed = 8;
    canshoot = 1;
    ball.visible = true;
  }
  /////////////////////////collide floor/////////////////////////
  if(ball.overlaps(floor) || ball.overlaps(ground) || ball.overlaps(ceiling) || ball.overlaps(walll) || ball.overlaps(wallr) || ball.overlaps(cornertl) || ball.overlaps(cornertr) || ball.overlaps(cornerbl) || ball.overlaps(cornerbr) ) {
    ball.x = player.x;
    ball.y = player.y;
    ball.speed = 0;
    canshoot = 0;
    ball.visible = false;
  }

  if(ball.y > 480){
    ball.x = player.x;
    ball.y = player.y;
    ball.speed = 0;
    canshoot = 0;
    ball.visible = false;
  }


  
/////////////////////////dash/////////////////////////
  let dashdistance = dist(dashstart.x, dashstart.y, dasher.x, dasher.y);
  if(mouse.pressing("right") && candash == 0){
    dashstart.x = player.x;
    dashstart.y = player.y;
    dasher.x = player.x;
    dasher.y = player.y;
    dashing+= 0.08;
  }
  else{
    cursor.ani.frame = 0;
  }
  if(mouse.released("right") && dashing >= 3){
    dasher.direction = dasher.angleTo(pointer);
    dasher.speed = 10;
    cursor.ani.frame = 0;
  }

  if(dashing >= 1 && dashing < 2 && mouse.released("right")){
    cursor.ani.frame = 1;
    dashing = 0;
  }
  else if(dashing >= 2 && dashing < 3 && mouse.released("right")){
    cursor.ani.frame = 2;
    dashing = 0;
  }

  if(dashing >= 1 && dashing < 2){
    cursor.ani.frame = 1;
  }
  else if(dashing >= 2 && dashing < 3){
    cursor.ani.frame = 2;
  }
  else if(dashing >= 3){
    cursor.ani.frame = 3;
    player.x = dasher.x;
    player.y = dasher.y;
  }
  if(dashdistance > 1){
    candash = 1;
  }
  if(dashdistance > 100){
    dasher.speed = 0;
    candash = 0;
    dashing = 0;
    hitbox.x = dasher.x;
    hitbox.y = dasher.y;
    dashstart.x = player.x;
    dashstart.y = player.y;
    player.velocity.y = -3
    s_slimetp.play();
    s_slimetp.setVolume(0.1);
  }

  if(dasher.overlaps(floor) || dasher.overlaps(ground) || dasher.overlaps(ceiling) || dasher.overlaps(walll) || dasher.overlaps(wallr) || dasher.overlaps(cornertl) || dasher.overlaps(cornertr) || dasher.overlaps(cornerbl) || dasher.overlaps(cornerbr) || dasher.overlaps(platformleft) || dasher.overlaps(platformright) ) {
    dasher.speed = 0;
    candash = 0;
    dashing = 0;
    hitbox.x = dasher.x;
    hitbox.y = dasher.y;
    dashstart.x = player.x;
    dashstart.y = player.y;
    player.velocity.y = -3;
    s_slimetp.play();
    s_slimetp.setVolume(0.1);
  }

  // console.log(dashdistance);
  // console.log(dashing);
}

