let player, playerSpawnX, playerSpawnY;
let ground;
let bgSprite;

let jump = 1;
let inair = 1;
let jumpforce = -1;

let jumpbar;
let hitbox;

let cursor;
let pointer;

let ball;
let canshoot = 0;

let candash = 0;
let dashing = 0;
let dasher;
let dashstart;


let sleeping = 0;
let canattack = 0;
let killed = 0;

let playerlife = 10;

let batsleep = 0;
let batdying = 0;
let batdead = 0;

let gamestart = 0;

let timer = 0;

let landsound = 0;

let gameended = 0;



function preload(){
    //allSprites.debug = true;

    //tileSet
    mur_plein = loadImage("assets/mur-plein.png");
    mur_bas = loadImage("assets/mur-b.png");
    mur_haut = loadImage("assets/mur-h.png");
    mur_droite = loadImage("assets/mur-d.png");
    mur_gauche = loadImage("assets/mur-g.png");
    coin_bd = loadImage("assets/coin-bd.png");
    coin_bg = loadImage("assets/coin-bg.png");
    coin_hd = loadImage("assets/coin-hd.png");
    coin_hg = loadImage("assets/coin-hg.png");
    coininverse_bd = loadImage("assets/coininverse-bd.png");
    coininverse_bg = loadImage("assets/coininverse-bg.png");
    coininverse_hd = loadImage("assets/coininverse-hd.png");
    coininverse_hg = loadImage("assets/coininverse-hg.png");
    mur_slime_gauche = loadImage("assets/slimewalll.png");
    mur_slime_droite = loadImage("assets/slimewallr.png");
    mur_slime_centre = loadImage("assets/slimewall.png");
    platformdroite = loadImage("assets/platformdroite.png");
    platformgauche = loadImage("assets/platformgauche.png");
    spikes_bas = loadImage("assets/spikes-bottom.png");
    spikes_haut = loadImage("assets/spikes-top.png");
    spikes_gauche = loadImage("assets/spikes-mur-gauche.png");
    spikes_droite = loadImage("assets/spikes-mur-droit.png");

    champi1_img = loadImage("assets/champi1.png");
    champi2_img = loadImage("assets/champi2.png");
    herbe1_img = loadImage("assets/herbe1.png");
    herbe_milieu_img = loadImage("assets/herbe-milieu.png");
    herbe_droite_img = loadImage("assets/herbe-droite.png");
    herbe_gauche_img = loadImage("assets/herbe-gauche.png");

    //background
    bg_foret = loadImage("assets/bg-foret.png");
    startScreenSprite = loadImage("assets/accueil.png");
    slimemenuSprite= loadImage("assets/slimemenu.png");
    victorySprite = loadImage("assets/victory.png");
    gameoverSprite = loadImage("assets/game-over.png");

    //player
    playerSprite = loadImage('assets/slimeall.png');
    lifebarSprite = loadImage('assets/lifebar.png');
    confiture = loadImage('assets/jam.png');

    //jumpbar
    jumpbarSprite = loadImage('assets/jumpbar.png');

    //cursor
    cursorSprite = loadImage('assets/cursor.png');
    ballSprite = loadImage('assets/slimeball.png');
    pointerSprite = loadImage('assets/pointer.png');

    //enemy
    mushroomSprite = loadImage('assets/mushroom.png');
    mushballSprite = loadImage('assets/mushball.png');

    batSprite = loadImage('assets/batanim.png');

    jamSprite = loadImage('assets/jam.png');




    s_slimeshoot = loadSound('son/slimeshoot.mp3');
    s_slimeland = loadSound('son/slimeland.mp3');
    s_slimejump = loadSound('son/slimejump.mp3');
    s_slimetp = loadSound('son/slimetp.mp3');
    s_slimehurt = loadSound('son/slimehurt.mp3');

    s_batfly = loadSound('son/batfly.mp3');
    s_batfly2 = loadSound('son/batfly2.mp3');
    s_batdeath = loadSound('son/batdeath.mp3');

    s_mushroomshoot = loadSound('son/mushroomshoot.mp3');
    s_mushroomdeath = loadSound('son/mushroomdeath.mp3');
    s_mushroomout = loadSound('son/mushroomout.mp3');
    s_mushroomout2 = loadSound('son/mushroomout2.mp3');

    s_musique = loadSound('son/musique.mp3');
    s_victory = loadSound('son/victory.mp3');
    s_lose = loadSound('son/lose.mp3');
    s_click = loadSound('son/click.mp3');
}



function setup() {
    allSprites.pixelPerfect = true;
	new Canvas(800, 480);
    world.gravity.y = 8.2;
    allSpritesGroup = new Group();

    startscreen = new Sprite(-1000, 240, 800, 480);
    startscreen.layer = 10;
	startscreen.rotationLock = true;
    startscreen.image = startScreenSprite;
	startscreen.collider = 'none';

    victory = new Sprite(-1000, 240, 800, 480);
    victory.layer = 10;
	victory.rotationLock = true;
    victory.image = victorySprite;
	victory.collider = 'none';

    gameover = new Sprite(-1000, 240, 800, 480);
    gameover.layer = 10;
	gameover.rotationLock = true;
    gameover.image = gameoverSprite;
	gameover.collider = 'none';

    slimemenu = new Sprite(-1000, 240, 800, 480);
    slimemenu.layer = 11;
	slimemenu.rotationLock = true;
	slimemenu.collider = 'none';
    slimemenu.spriteSheet = slimemenuSprite;
    slimemenu.addAnis({
		start: {
			row: 0,
			col: 0,
			frames: 18,
			frameSize: [800, 480],
			frameDelay: 4
		}
    });

    jam = new Sprite(4470, 272, 32, 32);
    jam.layer = 3;
    jam.rotationLock = true;
    jam.collider = 'none';
    jam.visible = true;
    jam.image = jamSprite;

    playerSpawnX = 110;
	playerSpawnY = 152;
	createPlayer();
    createCursor();
    createMushroom();
    createBat();
    

    
    ///////////////////map/////////////////////////
    ground = new Group();
    ground.layer = 1;
    ground.w = 32;
    ground.h = 32;
    ground.tile = "5";
    ground.collider = 'static';
    ground.image = mur_plein;
    
    floor = new Group();
    floor.layer = 1;
    floor.w = 32;
    floor.h = 32;
    floor.tile = "f";
    floor.collider = 'static';
    floor.image = mur_bas;

    ceiling = new Group();
    ceiling.layer = 1;
    ceiling.w = 32;
    ceiling.h = 32;
    ceiling.tile = "c";
    ceiling.collider = 'static';
    ceiling.image = mur_haut
    
    wallr = new Group();
    wallr.layer = 1;
    wallr.w = 32;
    wallr.h = 32;
    wallr.tile = "l";
    wallr.collider = 'static';
    wallr.image = mur_droite;
    
    walll = new Group();
    walll.layer = 1;
    walll.w = 32;
    walll.h = 32;
    walll.tile = "r";
    walll.collider = 'static';
    walll.image = mur_gauche;

    cornertr = new Group();
    cornertr.layer = 1;
    cornertr.w = 32;
    cornertr.h = 32;
    cornertr.tile = "9";
    cornertr.collider = 'static';
    cornertr.image = coin_hd;

    cornertl = new Group();
    cornertl.layer = 1;
    cornertl.w = 32;
    cornertl.h = 32;
    cornertl.tile = "7";
    cornertl.collider = 'static';
    cornertl.image = coin_hg;

    cornerbr = new Group();
    cornerbr.layer = 1;
    cornerbr.w = 32;
    cornerbr.h = 32;
    cornerbr.tile = "3";
    cornerbr.collider = 'static';
    cornerbr.image = coin_bd;

    cornerbl = new Group();
    cornerbl.layer = 1;
    cornerbl.w = 32;
    cornerbl.h = 32;
    cornerbl.tile = "1";
    cornerbl.collider = 'static';
    cornerbl.image = coin_bg;

    angletr = new Group();
    angletr.layer = 1;
    angletr.w = 32;
    angletr.h = 32;
    angletr.tile = "4";
    angletr.collider = 'static';
    angletr.image = coininverse_hd;

    angletl = new Group();
    angletl.layer = 1;
    angletl.w = 32;
    angletl.h = 32;
    angletl.tile = "2";
    angletl.collider = 'static';
    angletl.image = coininverse_hg;

    anglebr = new Group();
    anglebr.layer = 1;
    anglebr.w = 32;
    anglebr.h = 32;
    anglebr.tile = "8";
    anglebr.collider = 'static';
    anglebr.image = coininverse_bd;

    anglebl = new Group();
    anglebl.layer = 1;
    anglebl.w = 32;
    anglebl.h = 32;
    anglebl.tile = "6";
    anglebl.collider = 'static';
    anglebl.image = coininverse_bg;

    slimewalll = new Group();
    slimewalll.layer = 3;
    slimewalll.w = 32;
    slimewalll.h = 32;
    slimewalll.tile = "h";
    slimewalll.collider = 'none';
    slimewalll.image = mur_slime_gauche;
    
    slimewallr = new Group();
    slimewallr.layer = 3;
    slimewallr.w = 32;
    slimewallr.h = 32;
    slimewallr.tile = "k";
    slimewallr.collider = 'none';
    slimewallr.image = mur_slime_droite;

    slimewall = new Group();
    slimewall.layer = 3;
    slimewall.w = 32;
    slimewall.h = 32;
    slimewall.tile = "j";
    slimewall.collider = 'none';
    slimewall.image = mur_slime_centre;

    champi1 = new Group();
    champi1.layer = 3;
    champi1.w = 32;
    champi1.h = 32;
    champi1.tile = "p";
    champi1.collider = 'none';
    champi1.image = champi1_img;

    champi2 = new Group();
    champi2.layer = 3;
    champi2.w = 32;
    champi2.h = 32;
    champi2.tile = "o";
    champi2.collider = 'none';
    champi2.image = champi2_img;

    herbe1 = new Group();
    herbe1.layer = 3;
    herbe1.w = 32;
    herbe1.h = 32;
    herbe1.tile = "y";
    herbe1.collider = 'none';
    herbe1.image = herbe1_img;

    herbemid = new Group();
    herbemid.layer = 3;
    herbemid.w = 32;
    herbemid.h = 32;
    herbemid.tile = "u";
    herbemid.collider = 'none';
    herbemid.image = herbe_milieu_img;
    
    herberight = new Group();
    herberight.layer = 3;
    herberight.w = 32;
    herberight.h = 32;
    herberight.tile = "i";
    herberight.collider = 'none';
    herberight.image = herbe_droite_img;

    herbeleft = new Group();
    herbeleft.layer = 3;
    herbeleft.w = 32;
    herbeleft.h = 32;
    herbeleft.tile = "t";
    herbeleft.collider = 'none';
    herbeleft.image = herbe_gauche_img;

    spikesleft = new Group();
    spikesleft.layer = 3;
    spikesleft.w = 12;
    spikesleft.h = 26;
    spikesleft.tile = "q";
    spikesleft.collider = 'none';
    spikesleft.image = spikes_gauche;

    spikesright = new Group();
    spikesright.layer = 3;
    spikesright.w = 12;
    spikesright.h = 26;
    spikesright.tile = "d";
    spikesright.collider = 'none';
    spikesright.image = spikes_droite;

    spikestop = new Group();
    spikestop.layer = 3;
    spikestop.w = 26;
    spikestop.h = 12;
    spikestop.tile = "z";
    spikestop.collider = 'none';
    spikestop.image = spikes_haut;
    
    spikesbottom = new Group();
    spikesbottom.layer = 3;
    spikesbottom.w = 26;
    spikesbottom.h = 12;
    spikesbottom.tile = "x";
    spikesbottom.collider = 'none';
    spikesbottom.image = spikes_bas;

    platformleft = new Group();
    platformleft.layer = 1;
    platformleft.w = 32;
    platformleft.h = 32;
    platformleft.tile = "n";
    platformleft.collider = 'static';
    platformleft.image = platformdroite;

    platformright = new Group();
    platformright.layer = 1;
    platformright.w = 32;
    platformright.h = 32;
    platformright.tile = "b";
    platformright.collider = 'static';
    platformright.image = platformgauche;


    
    new Tiles(
        ['55555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555552cccccc45555555555555552cccccccc455555555555555',
         '55555555555555555555552cccccc4555552cccccccc4555555555555555555552cccccccccccc4552ccccc452cccccc45555555552cc3zzzzzz1cccccc455552ccc3........1c4555555555555',
         '55555555555555555552cc3......142ccc3........1c4552ccc455552cccccc3............1cc3.....1c3......1c45552ccc3.....it.........1cccc3..............l555555555555',
         '55555555555555555523..........lr..............1cc3...145523...................................it..l52c3.........79b............................1455555555555',
         '555555555555555555r...........13......................l55r.............................p......79..l5r....7f9...n13..............................l55555555555',
         '555555555555555555r...................................l523.............................79....dlr..14r...n1c3.........iyyt......................il55555555555',
         '555555555555555555r...................................1c3..............................lrb...dlr...lr.....z..........7ff9............iot.......7855555555555',
         '555555555555555555r....................................z...............................13....dlr...lr................l55r.....it.....7f9t......l555555555555',
         '555555555555555555r..........................it.......................iyyyoyyt................l69..lrb...............l55r.....79.....l569yyyyy78555555555555',
         '555555555555555555r........it........iyt.....79......it............iyy7ffffff9t............iyyl5r..13..iyyt.........n145r.....lr.....l556fffff85555555555555',
         '555555555555555555r........79........7f9.....lr......79...........d7ff855555569............7ff85r......7ff9xxyyt......l5r.....lr.....14555555555555555555555',
         '555555555555555555rp...it..lr........l5r.....lrq.....lr......it...d14555555555rxxyyyyyyt...l5555rt.....l556ffff9......l5r.....lr......l555555555555555555555',
         '55555555555555555569yyy79xxlr...iyyyol5r.....l69.....lr......79.....l5555555556ffffffff9xxxl555569....n14555555r......l5r.....lr......l555555555555555555555',
         '55555555555555555556fff86ff8r...7ffff85r.....l5r.....lr......lr.....l5555555555555555556fff855555r......l5555523......l5r.....lr......l555555555555555555555',
         '5555555555555555555555555555r...l555555r.....l5r.....lr......lr.....l5555555555555555555555555555r......l55555r.......l5r.....lr......l555555555555555555555',],
         16,
         16,
         ground.w,
         ground.h,
         
    );
}



function draw() {
    if(gamestart == 0){
        clear();

        startscreen.x = 400;
        startscreen.y = 240;
        slimemenu.x = 450;
        slimemenu.y = 130;
        gameover.x = -1000;
        gameover.y = 240;
        victory.x = -1000;
        victory.y = 240;
        
        slimemenu.changeAni("start");
        slimemenu.ani.noLoop();

        if(mouse.pressed("left")){
            gamestart = 1;
            player.x = 670;
            player.y = 350;
            s_musique.play();
    	    s_musique.setVolume(0.05);
            s_click.play();
    	    s_click.setVolume(0.2);
        }
        
    }

    if(gamestart == 1){
	    clear();
        background(bg_foret);
        noCursor();
        

        startscreen.x = -1000;
        startscreen.y = 240;
        slimemenu.x = -1000;
        slimemenu.y = 130;
        gameover.x = -1000;
        gameover.y = 240;
        victory.x = -1000;
        victory.y = 240;

        movePlayer();
        shootCursor();
        attackMushroom();
        attackBat();
        lifebar.x = player.x;
        camera.x = player.x;

        reset();
    }

    if(gamestart == 2){
        clear();
        gameended += 0.1;
        gameover.x = player.x;
        gameover.y = 240;
        player.velocity.x = 0;
    }

    if(gamestart == 3){
        clear();
        gameended += 0.1;
        victory.x = player.x;
        victory.y = 240;
        player.velocity.x = 0;
        s_musique.setVolume(0);
    }

    if(gameended >= 20){
        window.location.reload();
    }

     
}

function reset(){
    if(kb.pressed("p") && gamestart == 1){
        window.location.reload();
    }
}