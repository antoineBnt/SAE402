
<?php get_header();?>
<?php  if (have_posts()):
while (have_posts()):the_post();?>
    

<article  id="<?php the_id();?>"class="card">
              <img src="asset/actu-img.avif" alt="" class="card__img" />
              <p class="card__text">
                23/03/24 <span class="span__card">ACTUALITÉS</span>
              </p>
              <h3 class="card__subtitle">
                SORTIE DE NOTRE NOUVEAU PERSONNAGE EN EXCLUSIVITÉ
              </h3>
            </article>
     <?php endwhile; endif;?>