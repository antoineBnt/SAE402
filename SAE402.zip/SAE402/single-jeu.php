
<?php wp_head(); ?>
<div id="primary" class="content-area">
    <h2 class="trailer">DEMO MODE</h2>
    <main id="main" class="site-main" role="main">
        <div id="game-container">
           

        </div>
    </main>
</div>

