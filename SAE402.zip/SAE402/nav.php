  <nav class="nav">
          <img src="<?php the_field("img_logo")?>" alt="logo de notre jeu" class="nav__logo" />
          
         <?php
                
            wp_nav_menu(
                array(
                    'theme_location' => 'header-primary-menu',
                    'menu_id' => 'footer',
                    'container' => 'ul',
                    'menu_class' => 'nav__link-contain',
                )
            );
            
        ?>
        <article class="nav__switch">
            <div class="toggle-switch">
              <label class="switch-label">
                <input type="checkbox" class="checkbox" />
                <span class="slider"></span>
              </label>
            </div>

            <?php
$texte_du_bouton = "Play Now"; 


$args = array(
    'post_type' => 'jeu', 
    'posts_per_page' => -1 
);

$jeux_query = new WP_Query($args);

if ($jeux_query->have_posts()) : 
    while ($jeux_query->have_posts()) : $jeux_query->the_post();

        $game_permalink = get_permalink();
        ?>
        <a href="<?php echo esc_url($game_permalink); ?>" class="nav__btn">
            <?php echo esc_html($texte_du_bouton); ?>
        </a>
        <?php
    endwhile;
    wp_reset_postdata();
else :
    echo '<p>Aucun jeu trouvé.</p>';
endif;
?>
          </article>
        </nav>





