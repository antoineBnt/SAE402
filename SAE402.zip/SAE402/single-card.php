
<?php get_header();?>
<?php  if (have_posts()):
while (have_posts()):the_post();?>


            <article class="card">
              <img src="<?php the_field("img_card")?>" alt="" class="card__img" />
              <p class="card__text">
                <?php the_field("date_card")?><span class="span__card"><?php the_field("card_actu")?></span>
              </p>
              <h3 class="card__subtitle">
                <?php the_field("card_info")?>
              </h3>
            </article>

            
<?php endwhile; endif;?>