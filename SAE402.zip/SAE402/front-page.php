<?php 
get_header();
?>
<section class="BigContain">
<!-- page d'actualité de ma page -->
<?php include("nav.php"); ?>
<article id="header" class="play" style="background-image: url('<?php the_field('img_fond'); ?>');">
  <p class="play__text"><?php the_field('text_header'); ?></p>
   <?php
$texte_du_bouton = "Play Now"; 


$args = array(
    'post_type' => 'jeu', 
    'posts_per_page' => -1 
);

$jeux_query = new WP_Query($args);

if ($jeux_query->have_posts()) : 
    while ($jeux_query->have_posts()) : $jeux_query->the_post();

        $game_permalink = get_permalink();
        ?>
        <a href="<?php echo esc_url($game_permalink); ?>" class="play__btn">
            <?php echo esc_html($texte_du_bouton); ?>
        </a>
        <?php
    endwhile;
    wp_reset_postdata();
else :
    echo '<p>Aucun jeu trouvé.</p>';
endif;
?>

  <div class="container_mouse" id="scrollDownButton">
    <span class="mouse-btn">
      <span class="mouse-scroll"></span>
    </span>
  </div>
  <div class="container_mouse-1" id="scrollUpButton">
    <span class="mouse-btn-1">
      <span class="mouse-scroll-1"></span>
    </span>
  </div>
</article>
<section class="actu" id="actu">
        <h2 class="actu__absolute">JAMVE<br />NTURE</h2>
        <nav class="actu__nav">
          <h1 class="actu__nav-title">Derniere actu</h1>
          <div class="actu__right">
            <h2 class="actu__subtitle">Aller au actu</h2>
            <div class="actu__absolute-img">
              <svg
                width="161"
                height="136"
                viewBox="0 0 161 136"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                class="actu__arrow"
              >
                <path
                  d="M158.707 68.7071L159.414 68L158.707 67.2929L93.7071 2.29289L93 1.58578L92.2929 2.29289L83.1279 11.4579L82.4213 12.1645L83.1274 12.8716L130.693 60.5L2 60.5L0.999997 60.5L0.999997 61.5L0.999997 74.5L0.999997 75.5L2 75.5L130.693 75.5L83.1274 123.128L82.4213 123.835L83.1279 124.542L92.2929 133.707L93 134.414L93.7071 133.707L158.707 68.7071Z"
                  fill="var(--text-day)"
                  stroke="var(--text-day)"
                  stroke-width="2"
                />
              </svg>
            </div>
          </div>
        </nav>
<div class="actu__BigContain" >
  <div class="card__container">
    <?php
    $args = array(
        'post_type' => 'card', 
    );

    $query = new WP_Query($args);

    
    if ($query->have_posts()) {
        
        while ($query->have_posts()) {
            $query->the_post();
            ?>
            <article id="post-full-<?php the_ID(); ?>" <?php post_class('my-card'); ?>>
              <article class="card">
                <img src="<?php the_field("img_card")?>" alt="" class="card__img" />
                <p class="card__text">
                  <?php the_field("date_card")?> <span class="span__card"><?php the_field("card_actu")?></span>
                </p>
                <h3 class="card__subtitle">
                  <?php the_field("card_info")?>
                </h3>
              </article>
            </article>
            <?php
        }
        wp_reset_postdata(); 
    } 
    ?>
  </div>
</div>
</section>
  <section id="news" class="news">
    <h1 class="news__title">
      <?php the_field('titre_news')?>
    </h1>
    <article class="news__container">
      <div class="news__left">
        <h2 class="news__left-title"><?php the_field('subtitle_news')?></h2>
        <p class="news__text">
          <?php the_field('description_news')?>
        </p>
      </div>
      <div class="news__right">
        <img src="<?php the_field('img_news')?>" alt="" class="news__img" />
        <img src="" alt="" class="news__img-absolute" />
      </div>
    </article>
  </section>
</section>

 <!-- pouvoir joué au jeu sur la page de ma page -->

      <section class="game" id="play">
        <div class="line__top">
          <div class="top__contain">
            <div class="line-top"></div>
          </div>
        </div>
        <article class="game__container">
          <div class="iframe__container">
            
          
          <video class="game__trailer" controls>
            <source src="<?php echo get_template_directory_uri(); ?>/video/trailer jamventure_Trim.mp4" type="video/mp4">
          </video>
          </div>
        </article>
        <div class="line__bottom">
          <div class="bottom__contain">
            <div class="line-bottom"></div>
          </div>
        </div>
      </section>


<section class="perso" id="info">
        <article class="perso__left-contain">
          <article class="perso__left" style="background-image: url('<?php the_field('fond_perso'); ?>');">
            <lottie-player
              src="https://lottie.host/d9e68e93-03e4-4ca3-a82c-fff764835681/01YCEfa4Tf.json"
              class="svg__perso"
              background="transparent"
              speed="1"
              loop
              autoplay
            ></lottie-player>
          </article>
        </article>
        <article class="perso__right">
          <h1 class="perso__title"><?php the_field('perso_titre')?></h1>
          <h2 class="perso__subtitle"><?php the_field('perso_subtitle')?></h2>
          <p class="perso__text">
            <?php the_field('perso_texte')?>
          </p>
          <div class="perso__btn-contain">

            <?php
$texte_du_bouton = "Play Now"; 

$args = array(
    'post_type' => 'jeu', 
    'posts_per_page' => -1 
);

$jeux_query = new WP_Query($args);

if ($jeux_query->have_posts()) : 
    while ($jeux_query->have_posts()) : $jeux_query->the_post();

        $game_permalink = get_permalink();
        ?>
        <a href="<?php echo esc_url($game_permalink); ?>" class="perso__btn">
            <?php echo esc_html($texte_du_bouton); ?>
        </a>
        <?php
    endwhile;
    wp_reset_postdata();
else :
    echo '<p>Aucun jeu trouvé.</p>';
endif;
?>
          </div>
        </article>
      </section>






<?php get_footer(); ?>
