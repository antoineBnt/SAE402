function createMushroom() {
  mushroom = new Sprite(2780, 355, 32, 58);
  // mushroom.debug = true;
  mushroom.collider = "static";
  mushroom.layer = 2;
  mushroom.rotationLock = true;
  mushroom.spriteSheet = mushroomSprite;
  mushroom.addAnis({
    out: {
      row: 0,
      col: 0,
      frames: 8,
      frameSize: [32, 58],
      frameDelay: 8,
    },
    idle: {
      row: 0,
      col: 8,
      frames: 6,
      frameSize: [32, 58],
      frameDelay: 8,
    },
  });

  mushball = new Sprite(mushroom.x, mushroom.y, 12, 12);
  mushball.image = mushballSprite;
  mushball.layer = 1;
  mushball.collider = "none";
  mushball.mass = 0;
  mushball.visible = false;
}

function attackMushroom() {
  let enemydistance = dist(player.x, player.y, mushroom.x, mushroom.y);

  if (enemydistance > 200 && sleeping == 0 && killed == 0) {
    mushroom.changeAni("out");
    mushroom.ani.frame = 0;
  } else if (enemydistance < 200 && sleeping == 0 && killed == 0) {
    sleeping = 1;
  }
  if (sleeping == 1 && canattack < 0.6 && killed == 0) {
    mushroom.changeAni("out");
    mushroom.ani.noLoop();
    canattack += 0.01;
  } else if (canattack >= 0.6 && killed == 0) {
    mushroom.changeAni("idle");
    mushroom.ani.loop();
    canattack += 0.01;
  }
  if (canattack >= 1.3 && killed == 0) {
    mushball.x = mushroom.x;
    mushball.y = mushroom.y;
    mushball.direction = mushball.angleTo(player);
    mushball.speed = 6;
    mushball.visible = true;
    canattack = 0.5;
  }

  if (
    mushball.overlaps(floor) ||
    mushball.overlaps(ground) ||
    mushball.overlaps(ceiling) ||
    mushball.overlaps(walll) ||
    mushball.overlaps(wallr) ||
    mushball.overlaps(cornertl) ||
    mushball.overlaps(cornertr) ||
    mushball.overlaps(cornerbl) ||
    mushball.overlaps(cornerbr)
  ) {
    mushball.x = mushroom.x;
    mushball.y = mushroom.y;
    mushball.speed = 0;
    mushball.visible = false;
  }
  if (mushball.overlaps(hitbox)) {
    mushball.x = mushroom.x;
    mushball.y = mushroom.y;
    mushball.speed = 0;
    mushball.visible = false;
    playerlife -= 4;
  }

  if (hitbox.overlaps(mushroom) && killed == 0) {
    playerlife = 0;
  }

  if (ball.overlaps(mushroom) && killed == 0 && sleeping == 1) {
    killed = 1;
    mushroom.changeAni("out");
    mushroom.ani.rewind();
    mushroom.collider = "none";
    ball.x = player.x;
    ball.y = player.y;
    ball.speed = 0;
    canshoot = 0;
    ball.visible = false;
    mushball.x = mushroom.x;
    mushball.y = mushroom.y + 90;
    mushball.speed = 0;
    mushball.visible = false;
  }

  if (ball.overlaps(mushball)) {
    ball.x = player.x;
    ball.y = player.y;
    ball.speed = 0;
    canshoot = 0;
    ball.visible = false;
    mushball.x = mushroom.x;
    mushball.y = mushroom.y;
    mushball.speed = 0;
    mushball.visible = false;
  }
  // mushball.debug = true;
}

function createBat() {
  bat = new Sprite(3180, 80, 32, 32); //3312, 176
  // bat.debug = true;
  bat.collider = "none";
  bat.layer = 2;
  bat.rotationLock = true;
  bat.spriteSheet = batSprite;
  bat.addAnis({
    idle: {
      row: 0,
      col: 0,
      frames: 1,
      frameSize: [32, 32],
      frameDelay: 8,
    },
    damaged: {
      row: 0,
      col: 1,
      frames: 1,
      frameSize: [32, 32],
      frameDelay: 8,
    },
    fly: {
      row: 0,
      col: 2,
      frames: 8,
      frameSize: [32, 32],
      frameDelay: 8,
    },
  });

  batleft = new Sprite(3180, 225, 8, 8);
  batleft.collider = "static";
  batleft.rotationLock = true;
  batleft.visible = false;

  batright = new Sprite(3400, 225, 8, 8);
  batright.collider = "none";
  batright.rotationLock = true;
  batright.visible = false;
}

function attackBat() {
  let batdistance = dist(player.x, player.y, bat.x, bat.y);
  let batdodgedistance = dist(ball.x, ball.y, bat.x, bat.y);

  if (batdistance > 230 && batsleep == 0) {
    bat.changeAni("idle");
  }
  if (batdistance < 230 && batsleep == 0) {
    batsleep = 1;
    bat.changeAni("idle");
    bat.velocity.y = 4;
  }

  if (bat.overlaps(batright) && batdying <= 0.05) {
    bat.velocity.y = 0;
    bat.velocity.x = -2;
    bat.changeAni("fly");
    bat.mirror.x = false;
  }
  if (bat.overlaps(batleft) && batdying <= 0.05) {
    bat.velocity.y = 0;
    bat.velocity.x = 2;
    bat.changeAni("fly");
    bat.mirror.x = true;
  }

  if (batdodgedistance < 130 && batsleep == 0) {
    batsleep = 1;
    bat.changeAni("idle");
    bat.velocity.y = 4;
  }

  if (ball.overlaps(bat) && batsleep == 1 && bat.velocity.x == 2) {
    bat.changeAni("damaged");
    bat.velocity.x = 1;
    bat.velocity.y = 0.5;
    batdead = 1;
  }
  if (ball.overlaps(bat) && batsleep == 1 && bat.velocity.x == -2) {
    bat.changeAni("damaged");
    bat.velocity.x = -1;
    bat.velocity.y = 0.5;
    batdead = 1;
  }
  if (batdead == 1) {
    batdying += 0.05;
  }
  if (batdying >= 2) {
    bat.visible = false;
    bat.x = -1000;
    bat.velocity.x = 0;
    bat.velocity.y = 0;
  }

  if (bat.overlaps(hitbox) && batdead == 0) {
    playerlife = 0;
  }
}
