function createPlayer() {
  allSprites.pixelPerfect = true;
  new Canvas(800, 480);
  world.gravity.y = 8.2;

  //////////////////////player////////////////////////
  player = new Sprite(3000, 250, 25, 30);
  player.friction = 0;
  player.bounciness = 0;
  player.strokeWeight = 0;
  player.addCollider(0, 0, 0);
  //player.debug = true;
  player.layer = 2;
  player.rotationLock = true;
  player.spriteSheet = playerSprite;
  player.addAnis({
    idle: {
      row: 0,
      col: 0,
      frames: 8,
      frameSize: [32, 32],
      frameDelay: 8,
    },
    walk: {
      row: 0,
      col: 8,
      frames: 6,
      frameSize: [32, 32],
      frameDelay: 8,
    },
    jump: {
      row: 0,
      col: 14, //18
      frames: 5, //1
      frameSize: [32, 32],
      frameDelay: 8,
    },
    fall: {
      row: 0,
      col: 21,
      frames: 1,
      frameSize: [32, 32],
      frameDelay: 8,
    },
    dead: {
      row: 0,
      col: 22,
      frames: 1,
      frameSize: [32, 32],
      frameDelay: 8,
    },
    pushing: {
      row: 0,
      col: 23,
      frames: 1,
      frameSize: [32, 32],
      frameDelay: 8,
    },
    climbing: {
      row: 0,
      col: 24,
      frames: 6,
      frameSize: [32, 32],
      frameDelay: 8,
    },
  });

  player.changeAni("idle");

  lifebar = new Sprite(player.x, 32, 203, 19);
  //lifebar.debug = true;
  lifebar.layer = 4;
  lifebar.rotationLock = true;
  lifebar.spriteSheet = lifebarSprite;
  lifebar.collider = "none";
  lifebar.addAnis({
    hp: {
      row: 0,
      col: 0,
      frames: 11,
      frameSize: [203, 19],
      frameDelay: 8,
    },
  });

  hitbox = new Sprite(player.x, player.y + 5, 31, 20);
  j = new GlueJoint(player, hitbox);
  j.visible = false;
  hitbox.friction = 0;
  hitbox.bounciness = 0;
  hitbox.strokeWeight = 0;
  hitbox.rotationLock = false;
  hitbox.visible = false;
  hitbox.mass = 1;

  jumpbar = new Sprite(player.x, player.y - 15, 32, 32);
  // jumpbar.debug = true;
  jumpbar.collider = "none";
  // jumpbar.visible = true;
  jumpbar.layer = 2;
  jumpbar.spriteSheet = jumpbarSprite;
  jumpbar.addAnis({
    load: {
      row: 0,
      col: 0,
      frames: 6,
      frameSize: [32, 32],
      frameDelay: 8,
    },
  });
}

function movePlayer() {
  // console.log(jumpforce)
  if (kb.pressing("arrowRight")) {
    player.mirror.x = false;
    player.changeAni("walk");
    player.velocity.x = 3;
  } else if (kb.pressing("arrowLeft")) {
    player.mirror.x = true;
    player.changeAni("walk");
    player.velocity.x = -3;
  } else {
    player.changeAni("idle");
    player.velocity.x = 0;
  }

  ////////////////////////////////jump////////////////////////////////
  if (kb.pressing("arrowUp") && kb.pressing("arrowRight") && jump == 0) {
    player.velocity.x = 1;
    jumpforce -= 0.2;
  } else if (kb.pressing("arrowUp") && kb.pressing("arrowLeft") && jump == 0) {
    player.velocity.x = -1;
    jumpforce -= 0.2;
  } else if (kb.pressing("arrowUp") && jump == 0) {
    player.velocity.x = 0;
    jumpforce -= 0.2;
  }

  if (kb.released("arrowUp") && jump == 0) {
    player.velocity.y = Math.max(-9, jumpforce);
    jump = 1;
    inair = 1;
    player.changeAni("idle");
    jumpforce = -1.7;
  }
  if (jumpforce <= -1.8 && jumpforce > -3.6) {
    player.changeAni("jump");
    player.ani.frame = 0;
    jumpbar.changeAni("load");
    jumpbar.ani.frame = 1;
  } else if (jumpforce <= -3.6 && jumpforce > -5.4) {
    player.changeAni("jump");
    player.ani.frame = 1;
    jumpbar.changeAni("load");
    jumpbar.ani.frame = 2;
  } else if (jumpforce <= -5.4 && jumpforce > -7.2) {
    player.changeAni("jump");
    player.ani.frame = 2;
    jumpbar.changeAni("load");
    jumpbar.ani.frame = 3;
  } else if (jumpforce <= -7.2 && jumpforce > -9) {
    player.changeAni("jump");
    player.ani.frame = 3;
    jumpbar.changeAni("load");
    jumpbar.ani.frame = 4;
  } else if (jumpforce <= -9) {
    player.changeAni("jump");
    player.ani.frame = 4;
    jumpbar.changeAni("load");
    jumpbar.ani.frame = 5;
  } else {
    player.changeAni("idle");
    jumpbar.changeAni("load");
    jumpbar.ani.frame = 0;
  }

  if (
    player.collide(floor) ||
    player.collide(cornertl) ||
    player.collide(cornertr) ||
    player.collide(platformleft) ||
    player.collide(platformright)
  ) {
    jump = 0;
    inair = 0;
    player.changeAni("idle");
  }
  // console.log(jumpforce);

  ///////////////////////jumpbar///////////////////////
  jumpbar.x = player.x;
  jumpbar.y = player.y - 15;

  ////////////////////barre de vie/////////////////////

  if (playerlife >= 10) {
    lifebar.ani.frame = 0;
    playerlife = 10;
  } else if (playerlife == 9) {
    lifebar.ani.frame = 1;
  } else if (playerlife == 8) {
    lifebar.ani.frame = 2;
  } else if (playerlife == 7) {
    lifebar.ani.frame = 3;
  } else if (playerlife == 6) {
    lifebar.ani.frame = 4;
  } else if (playerlife == 5) {
    lifebar.ani.frame = 5;
  } else if (playerlife == 4) {
    lifebar.ani.frame = 6;
  } else if (playerlife == 3) {
    lifebar.ani.frame = 7;
  } else if (playerlife == 2) {
    lifebar.ani.frame = 8;
  } else if (playerlife == 1) {
    lifebar.ani.frame = 9;
  } else if (playerlife <= 0) {
    lifebar.ani.frame = 10;
    playerlife = 0;
  }

  // console.log(playerlife);

  if (player.y > 480) {
    playerlife = 0;
  }
}
