let player, playerSpawnX, playerSpawnY;
let ground;
let bgSprite;

let jump = 1;
let inair = 1;
let jumpforce = -1;

let jumpbar;
let hitbox;

let cursor;
let pointer;

let ball;
let canshoot = 0;

let candash = 0;
let dashing = 0;
let dasher;
let dashstart;

let sleeping = 0;
let canattack = 0;
let killed = 0;

let playerlife = 10;

let batsleep = 0;
let batdying = 0;
let batdead = 0;

let gamestart = 1;

function preload() {
  //allSprites.debug = true;

  //tileSet
  mur_plein = loadImage(gameAssets.baseurl + "mur-plein.png");
  mur_bas = loadImage(gameAssets.baseurl + "mur-b.png");
  mur_haut = loadImage(gameAssets.baseurl + "mur-h.png");
  mur_droite = loadImage(gameAssets.baseurl + "mur-d.png");
  mur_gauche = loadImage(gameAssets.baseurl + "mur-g.png");
  coin_bd = loadImage(gameAssets.baseurl + "coin-bd.png");
  coin_bg = loadImage(gameAssets.baseurl + "coin-bg.png");
  coin_hd = loadImage(gameAssets.baseurl + "coin-hd.png");
  coin_hg = loadImage(gameAssets.baseurl + "coin-hg.png");
  coininverse_bd = loadImage(gameAssets.baseurl + "coininverse-bd.png");
  coininverse_bg = loadImage(gameAssets.baseurl + "coininverse-bg.png");
  coininverse_hd = loadImage(gameAssets.baseurl + "coininverse-hd.png");
  coininverse_hg = loadImage(gameAssets.baseurl + "coininverse-hg.png");
  mur_slime_gauche = loadImage(gameAssets.baseurl + "slimewalll.png");
  mur_slime_droite = loadImage(gameAssets.baseurl + "slimewallr.png");
  mur_slime_centre = loadImage(gameAssets.baseurl + "slimewall.png");
  platformdroite = loadImage(gameAssets.baseurl + "platformdroite.png");
  platformgauche = loadImage(gameAssets.baseurl + "platformgauche.png");
  spikes_bas = loadImage(gameAssets.baseurl + "spikes-bottom.png");
  spikes_haut = loadImage(gameAssets.baseurl + "spikes-top.png");
  spikes_gauche = loadImage(gameAssets.baseurl + "spikes-mur-gauche.png");
  spikes_droite = loadImage(gameAssets.baseurl + "spikes-mur-droit.png");
  // Plantes et champignons
  champi1_img = loadImage(gameAssets.baseurl + "champi1.png");
  champi2_img = loadImage(gameAssets.baseurl + "champi2.png");
  herbe1_img = loadImage(gameAssets.baseurl + "herbe1.png");
  herbe_milieu_img = loadImage(gameAssets.baseurl + "herbe-milieu.png");
  herbe_droite_img = loadImage(gameAssets.baseurl + "herbe-droite.png");
  herbe_gauche_img = loadImage(gameAssets.baseurl + "herbe-gauche.png");

  // Background
  bg_foret = loadImage(gameAssets.baseurl + "bg-foret.png");
  startScreenSprite = loadImage(gameAssets.baseurl + "startscreen.png");

  // Player
  playerSprite = loadImage(gameAssets.baseurl + "slimeall.png");
  lifebarSprite = loadImage(gameAssets.baseurl + "lifebar.png");
  confiture = loadImage(gameAssets.baseurl + "jam.png");

  // Jumpbar
  jumpbarSprite = loadImage(gameAssets.baseurl + "jumpbar.png");

  // Cursor
  cursorSprite = loadImage(gameAssets.baseurl + "cursor.png");
  ballSprite = loadImage(gameAssets.baseurl + "slimeball.png");
  pointerSprite = loadImage(gameAssets.baseurl + "pointer.png");

  // Enemy
  mushroomSprite = loadImage(gameAssets.baseurl + "mushroom.png");
  mushballSprite = loadImage(gameAssets.baseurl + "mushball.png");

  // Bat
  batSprite = loadImage(gameAssets.baseurl + "batanim.png");
}

function setup() {
  allSprites.pixelPerfect = true;
  new Canvas(800, 480);
  world.gravity.y = 8.2;
  allSpritesGroup = new Group();

  startscreen = new Sprite(-1000, 240, 800, 480);
  startscreen.layer = 10;
  startscreen.rotationLock = true;
  startscreen.image = startScreenSprite;
  startscreen.collider = "none";

  playerSpawnX = 110;
  playerSpawnY = 152;
  createPlayer();
  createCursor();
  createMushroom();
  createBat();

  ///////////////////map/////////////////////////
  ground = new Group();
  ground.layer = 1;
  ground.w = 32;
  ground.h = 32;
  ground.tile = "5";
  ground.collider = "static";
  ground.image = mur_plein;

  floor = new Group();
  floor.layer = 1;
  floor.w = 32;
  floor.h = 32;
  floor.tile = "f";
  floor.collider = "static";
  floor.image = mur_bas;

  ceiling = new Group();
  ceiling.layer = 1;
  ceiling.w = 32;
  ceiling.h = 32;
  ceiling.tile = "c";
  ceiling.collider = "static";
  ceiling.image = mur_haut;

  wallr = new Group();
  wallr.layer = 1;
  wallr.w = 32;
  wallr.h = 32;
  wallr.tile = "l";
  wallr.collider = "static";
  wallr.image = mur_droite;

  walll = new Group();
  walll.layer = 1;
  walll.w = 32;
  walll.h = 32;
  walll.tile = "r";
  walll.collider = "static";
  walll.image = mur_gauche;

  cornertr = new Group();
  cornertr.layer = 1;
  cornertr.w = 32;
  cornertr.h = 32;
  cornertr.tile = "9";
  cornertr.collider = "static";
  cornertr.image = coin_hd;

  cornertl = new Group();
  cornertl.layer = 1;
  cornertl.w = 32;
  cornertl.h = 32;
  cornertl.tile = "7";
  cornertl.collider = "static";
  cornertl.image = coin_hg;

  cornerbr = new Group();
  cornerbr.layer = 1;
  cornerbr.w = 32;
  cornerbr.h = 32;
  cornerbr.tile = "3";
  cornerbr.collider = "static";
  cornerbr.image = coin_bd;

  cornerbl = new Group();
  cornerbl.layer = 1;
  cornerbl.w = 32;
  cornerbl.h = 32;
  cornerbl.tile = "1";
  cornerbl.collider = "static";
  cornerbl.image = coin_bg;

  angletr = new Group();
  angletr.layer = 1;
  angletr.w = 32;
  angletr.h = 32;
  angletr.tile = "4";
  angletr.collider = "static";
  angletr.image = coininverse_hd;

  angletl = new Group();
  angletl.layer = 1;
  angletl.w = 32;
  angletl.h = 32;
  angletl.tile = "2";
  angletl.collider = "static";
  angletl.image = coininverse_hg;

  anglebr = new Group();
  anglebr.layer = 1;
  anglebr.w = 32;
  anglebr.h = 32;
  anglebr.tile = "8";
  anglebr.collider = "static";
  anglebr.image = coininverse_bd;

  anglebl = new Group();
  anglebl.layer = 1;
  anglebl.w = 32;
  anglebl.h = 32;
  anglebl.tile = "6";
  anglebl.collider = "static";
  anglebl.image = coininverse_bg;

  slimewalll = new Group();
  slimewalll.layer = 3;
  slimewalll.w = 32;
  slimewalll.h = 32;
  slimewalll.tile = "h";
  slimewalll.collider = "none";
  slimewalll.image = mur_slime_gauche;

  slimewallr = new Group();
  slimewallr.layer = 3;
  slimewallr.w = 32;
  slimewallr.h = 32;
  slimewallr.tile = "k";
  slimewallr.collider = "none";
  slimewallr.image = mur_slime_droite;

  slimewall = new Group();
  slimewall.layer = 3;
  slimewall.w = 32;
  slimewall.h = 32;
  slimewall.tile = "j";
  slimewall.collider = "none";
  slimewall.image = mur_slime_centre;

  champi1 = new Group();
  champi1.layer = 3;
  champi1.w = 32;
  champi1.h = 32;
  champi1.tile = "p";
  champi1.collider = "none";
  champi1.image = champi1_img;

  champi2 = new Group();
  champi2.layer = 3;
  champi2.w = 32;
  champi2.h = 32;
  champi2.tile = "o";
  champi2.collider = "none";
  champi2.image = champi2_img;

  herbe1 = new Group();
  herbe1.layer = 3;
  herbe1.w = 32;
  herbe1.h = 32;
  herbe1.tile = "y";
  herbe1.collider = "none";
  herbe1.image = herbe1_img;

  herbemid = new Group();
  herbemid.layer = 3;
  herbemid.w = 32;
  herbemid.h = 32;
  herbemid.tile = "u";
  herbemid.collider = "none";
  herbemid.image = herbe_milieu_img;

  herberight = new Group();
  herberight.layer = 3;
  herberight.w = 32;
  herberight.h = 32;
  herberight.tile = "i";
  herberight.collider = "none";
  herberight.image = herbe_droite_img;

  herbeleft = new Group();
  herbeleft.layer = 3;
  herbeleft.w = 32;
  herbeleft.h = 32;
  herbeleft.tile = "t";
  herbeleft.collider = "none";
  herbeleft.image = herbe_gauche_img;

  spikesleft = new Group();
  spikesleft.layer = 1;
  spikesleft.w = 32;
  spikesleft.h = 32;
  spikesleft.tile = "q";
  spikesleft.collider = "none";
  spikesleft.image = spikes_gauche;

  spikesright = new Group();
  spikesright.layer = 1;
  spikesright.w = 32;
  spikesright.h = 32;
  spikesright.tile = "d";
  spikesright.collider = "none";
  spikesright.image = spikes_droite;

  spikestop = new Group();
  spikestop.layer = 1;
  spikestop.w = 32;
  spikestop.h = 32;
  spikestop.tile = "z";
  spikestop.collider = "none";
  spikestop.image = spikes_haut;

  spikesbottom = new Group();
  spikesbottom.layer = 1;
  spikesbottom.w = 32;
  spikesbottom.h = 32;
  spikesbottom.tile = "x";
  spikesbottom.collider = "none";
  spikesbottom.image = spikes_bas;

  platformleft = new Group();
  platformleft.layer = 1;
  platformleft.w = 32;
  platformleft.h = 32;
  platformleft.tile = "n";
  platformleft.collider = "static";
  platformleft.image = platformdroite;

  platformright = new Group();
  platformright.layer = 1;
  platformright.w = 32;
  platformright.h = 32;
  platformright.tile = "b";
  platformright.collider = "static";
  platformright.image = platformgauche;

  new Tiles(
    [
      "5555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555552cccccc4555555555555555555555555555555",
      "55555555555555555555552cccccc4555552cccccccc4555555555555555555552cccccccccccc4552ccccc4555555552cc3......1ccccc.........................",
      "55555555555555555552cc3......142ccc3........1c4552ccc455552cccccc3............1cc3.....145552cc4r........................................",
      "55555555555555555523..........lr..............1cc3...145523.............................l52c3..hkt....79.................................",
      "555555555555555555r...........13......................l55r..............................l5r....l69....13.................................",
      "555555555555555555r...................................l523..............................14r...n1c3.......................................",
      "555555555555555555r...................................1c3................................lr................7.............................",
      "555555555555555555r......................................................................hk................l.............................",
      "555555555555555555r..........................it.......................iyyyoyyt...........lrb...............l.............................",
      "555555555555555555r........it........iyt.....79......it............iyy7ffffff9t..........lr..iyyt..........14............................",
      "555555555555555555r........79........7f9.....lr......79............7ff855555569..........13..7ff9yyyyt......l............................",
      "555555555555555555rp...it..lr........l5r.....lr......lr......it....14555555555ryyyyyyyyyt....l556ffff9......l............................",
      "55555555555555555569yyy79yylr...iyyyol5r.....l69.....lr......79.....l5555555556fffffffff9....14555555r......l...........................",
      "55555555555555555556fff86ff8r...7ffff85r.....l5r.....lr......lr.....l5555555555555555555r.....l5555523......l...........................",
      "5555555555555555555555555555r...l555555r.....l5r.....lr......lr.....l5555555555555555555r.....l55555r.......l...........................",
    ],
    16,
    16,
    ground.w,
    ground.h
  );
}

function draw() {
  if (gamestart == 0) {
    clear();

    startscreen.x = 400;
    startscreen.y = 240;
  }

  if (gamestart == 1) {
    clear();
    background(bg_foret);
    noCursor();

    startscreen.x = -1000;
    startscreen.y = 240;

    movePlayer();
    shootCursor();
    attackMushroom();
    attackBat();
    lifebar.x = player.x;
    camera.x = player.x;
  }
}
