// Code pour avoir le cercle qui suit la souris

// let mouseX = 0,
//   mouseY = 0,
//   currentX = 0,
//   currentY = 0;
// const damping = 0.4;

// document.addEventListener("mousemove", (e) => {
//   mouseX = e.pageX;
//   mouseY = e.pageY;
// });

// function animate() {
//   const diffX = mouseX - currentX;
//   const diffY = mouseY - currentY;

//   currentX += diffX * damping;
//   currentY += diffY * damping;

//   const cursor = document.getElementById("cursorCircle");
//   cursor.style.left = currentX + "px";
//   cursor.style.top = currentY + "px";

//   requestAnimationFrame(animate);
// }

// animate();

// document.addEventListener("mousedown", (e) => {
//   const cursor = document.getElementById("cursorCircle");
//   cursor.classList.add("clicked");
// });

// document.addEventListener("mouseup", () => {
//   const cursor = document.getElementById("cursorCircle");
//   cursor.classList.remove("clicked");
// });

// document.addEventListener("mouseover", (e) => {
//   if (
//     e.target.tagName === "A" ||
//     e.target.tagName === "BUTTON" ||
//     e.target.getAttribute("role") === "button"
//   ) {
//     const cursor = document.getElementById("cursorCircle");
//     cursor.classList.add("hovered");
//   }
// });

// document.addEventListener("mouseout", (e) => {
//   if (
//     e.target.tagName === "A" ||
//     e.target.tagName === "BUTTON" ||
//     e.target.getAttribute("role") === "button"
//   ) {
//     const cursor = document.getElementById("cursorCircle");
//     cursor.classList.remove("hovered");
//   }
// });

// ---------------PARALLAX ANIMATION----------------

// document.addEventListener("scroll", function () {
//   let aboutSection = document.querySelector(".play");
//   let rect = aboutSection.getBoundingClientRect();
//   let height = window.innerHeight || document.documentElement.clientHeight;

//   if (rect.top <= height / 2 && rect.bottom >= height / 2) {
//     aboutSection.classList.add("parallax-active");
//   } else {
//     aboutSection.classList.remove("parallax-active");
//   }
// });

document.addEventListener("scroll", function () {
  let aboutSection = document.querySelector(".news");
  let rect = aboutSection.getBoundingClientRect();
  let height = window.innerHeight || document.documentElement.clientHeight;

  if (rect.top <= height / 2 && rect.bottom >= height / 2) {
    aboutSection.classList.add("parallax-active");
  } else {
    aboutSection.classList.remove("parallax-active");
  }
});

// document.addEventListener("scroll", function () {
//   let aboutSection = document.querySelector(".footer");
//   let rect = aboutSection.getBoundingClientRect();
//   let height = window.innerHeight || document.documentElement.clientHeight;

//   if (rect.top <= height / 2 && rect.bottom >= height / 2) {
//     aboutSection.classList.add("parallax-active");
//   } else {
//     aboutSection.classList.remove("parallax-active");
//   }
// });

document.addEventListener("scroll", function () {
  let aboutSection = document.querySelector(".actu");
  let rect = aboutSection.getBoundingClientRect();
  let height = window.innerHeight || document.documentElement.clientHeight;

  if (rect.top <= height / 2 && rect.bottom >= height / 2) {
    aboutSection.classList.add("parallax-active");
  } else {
    aboutSection.classList.remove("parallax-active");
  }
});

document.addEventListener("scroll", function () {
  let aboutSection = document.querySelector(".perso");
  let rect = aboutSection.getBoundingClientRect();
  let height = window.innerHeight || document.documentElement.clientHeight;

  if (rect.top <= height / 2 && rect.bottom >= height / 2) {
    aboutSection.classList.add("parallax-active");
  } else {
    aboutSection.classList.remove("parallax-active");
  }
});

document.addEventListener("scroll", function () {
  let aboutSection = document.querySelector(".game");
  let rect = aboutSection.getBoundingClientRect();
  let height = window.innerHeight || document.documentElement.clientHeight;

  if (rect.top <= height / 2 && rect.bottom >= height / 2) {
    aboutSection.classList.add("parallax-active");
  } else {
    aboutSection.classList.remove("parallax-active");
  }
});

// -------------------------ANIMATION DES CARDS DE ACTUALITÉ---------------

document.addEventListener("DOMContentLoaded", function () {
  let links = document.querySelectorAll(".my-card");

  if (links.length > 0) {
    console.log("Les éléments .card ont été trouvés");

    links.forEach((link) => {
      link.addEventListener("mouseover", function () {
        console.log("Mouseover on", this);
        links.forEach((innerLink) => {
          if (innerLink !== this) {
            innerLink.style.opacity = "0.5";
            innerLink.style.transform = "scale(0.8)";
          }
        });

        this.style.opacity = "1";
        this.style.transform = "scale(1.2)";
      });

      link.addEventListener("mouseout", function () {
        console.log("Mouseout on", this);
        links.forEach((innerLink) => {
          innerLink.style.opacity = "1";
          innerLink.style.transform = "scale(1)";
        });
      });
    });
  } else {
    console.error("Erreur : Aucun élément .card trouvé sur la page.");
  }
});

// ------------animation pour qu'il y ai des carré sur ma page------------

function generateSquares(numberOfSquares) {
  const body = document.body;
  const bodyRect = body.getBoundingClientRect();
  const colors = ["#AD1A53", "#3D707F", "#67A594"];
  const sizes = [4, 6, 8];

  for (let i = 0; i < numberOfSquares; i++) {
    const square = document.createElement("div");
    square.className = "square";

    // Choisir une couleur aléatoire pour chaque carré
    const colorIndex = Math.floor(Math.random() * colors.length);
    square.style.backgroundColor = colors[colorIndex];

    // Choisir une taille aléatoire pour chaque carré
    const sizeIndex = Math.floor(Math.random() * sizes.length);
    const size = sizes[sizeIndex];
    square.style.width = `${size}px`;
    square.style.height = `${size}px`;

    // Positionner le carré de manière aléatoire sur le body
    const posX = Math.floor(Math.random() * bodyRect.width);
    const posY = Math.floor(Math.random() * bodyRect.height);

    square.style.left = `${posX}px`;
    square.style.top = `${posY}px`;

    body.appendChild(square);
  }
}

// Assurez-vous que le DOM est entièrement chargé avant d'exécuter la fonction
document.addEventListener("DOMContentLoaded", function () {
  console.log("DOM entièrement chargé.");
  generateSquares(90);
});

// --------ANIMATION NAV AU SCROLL-----------

document.addEventListener("DOMContentLoaded", function () {
  const checkbox = document.querySelector(".checkbox");

  checkbox.addEventListener("change", function () {
    if (this.checked) {
      // Mode nuit
      document.documentElement.style.setProperty("--text-day", "var(--white)");
      document.documentElement.style.setProperty(
        "--background-day",
        "var(--dark)"
      );
      document.documentElement.style.setProperty(
        "--deco-day",
        "var(--grey-black)"
      );
    } else {
      // Mode jour
      document.documentElement.style.setProperty("--text-day", "var(--dark)");
      document.documentElement.style.setProperty(
        "--background-day",
        "var(--white)"
      );
      document.documentElement.style.setProperty(
        "--deco-day",
        "var(--grey-light)"
      );
    }
  });
});

//CHANGEMENT DE COULEUR DE LA NAV

window.addEventListener("scroll", function () {
  const nav = document.querySelector("nav");
  if (window.scrollY > 0) {
    // Changer 0 par la valeur de défilement désirée pour activer le changement de couleur
    nav.classList.add("nav__scrolled");
  } else {
    nav.classList.remove("nav__scrolled");
  }
});
